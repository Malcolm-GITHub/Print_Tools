1 - Download and install Canon Service Tool V3400
2 - Enter maintenance mode on printer
3 - Power off printer
4 - Connect printer to pc with usb cable (service tool installed and open)
5 - Hold on the "resume" button (triangle in a circle) and press power
6 - Hold on these two buttons until the power led lights up
7 - Release the "resume" button, but not the power button, and press the "resume" button 5 times
  - {The light will change from power led white to reume led orange on each press of the resume button.}
8 - Release the two buttons. Power led will flash. Wait until it stops.
9 - You are now in maintenance mode.
10 - Run the service tool 3400
11 - In the section "Ink absorber counter", choose "main"
In the section "Counter value (%)" choose set at 0 % and click set

error 002 - Function not supported by printer
error 005 - The printer  is not compatible with this service tool try anouther version

All versions of Canon service tool up to v5

https://github.com/shpgn/service_tool_canon/releases

Document and full tests completed on 30/5/2025 By Advanced IT Scottburgh 063 581 9008 Malcolm Marcus

Test environment : Canon mb2740 series printer 30/5/25